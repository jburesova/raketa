using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;

namespace RaketaGame
{
    public class GameForm : Form
    {
        Timer gameTimer;
        Random rand = new Random();

        Rectangle player;
        int playerSpeed = 8;
        int playerWidth = 50;
        int playerHeight = 30;

        List<Drop> drops = new List<Drop>();
        int dropSpawnCounter = 0;
        int dropSpawnInterval = 20; // lower = more drops
        int dropSpeedMin = 3;
        int dropSpeedMax = 7;

        int lives = 3;
        int score = 0;
        bool leftPressed = false;
        bool rightPressed = false;
        bool gameOver = false;

        Font uiFont = new Font("Consolas", 14, FontStyle.Bold);

        public GameForm()
        {
            this.DoubleBuffered = true;
            this.ClientSize = new Size(600, 800);
            this.Text = "Raketa - vyhýbej se kapkám";

            // initialize player at bottom center
            player = new Rectangle((ClientSize.Width - playerWidth) / 2, ClientSize.Height - playerHeight - 10, playerWidth, playerHeight);

            // timer
            gameTimer = new Timer();
            gameTimer.Interval = 16; // ~60 FPS
            gameTimer.Tick += GameLoop;
            gameTimer.Start();

            // keys
            this.KeyDown += GameForm_KeyDown;
            this.KeyUp += GameForm_KeyUp;

            // mouse click for restart when game over
            this.MouseClick += GameForm_MouseClick;
        }

        private void GameForm_MouseClick(object sender, MouseEventArgs e)
        {
            if (gameOver)
            {
                Restart();
            }
        }

        private void GameForm_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Left) leftPressed = false;
            if (e.KeyCode == Keys.Right) rightPressed = false;
            if (e.KeyCode == Keys.R && gameOver) Restart();
        }

        private void GameForm_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Left) leftPressed = true;
            if (e.KeyCode == Keys.Right) rightPressed = true;
        }

        private void GameLoop(object sender, EventArgs e)
        {
            if (gameOver) { Invalidate(); return; }

            // player movement
            if (leftPressed)
            {
                player.X -= playerSpeed;
                if (player.X < 0) player.X = 0;
            }
            if (rightPressed)
            {
                player.X += playerSpeed;
                if (player.X + player.Width > ClientSize.Width) player.X = ClientSize.Width - player.Width;
            }

            // spawn drops
            dropSpawnCounter++;
            if (dropSpawnCounter >= dropSpawnInterval)
            {
                dropSpawnCounter = 0;
                int x = rand.Next(0, Math.Max(1, ClientSize.Width - 8));
                int size = rand.Next(6, 18);
                int speed = rand.Next(dropSpeedMin, dropSpeedMax + 1);
                drops.Add(new Drop(new Rectangle(x, -size, size, size), speed));
            }

            // update drops
            for (int i = drops.Count - 1; i >= 0; i--)
            {
                drops[i].Rect = new Rectangle(drops[i].Rect.X, drops[i].Rect.Y + drops[i].Speed, drops[i].Rect.Width, drops[i].Rect.Height);

                // collision with player
                if (drops[i].Rect.IntersectsWith(player))
                {
                    drops.RemoveAt(i);
                    lives--;
                    if (lives <= 0)
                    {
                        lives = 0;
                        gameOver = true;
                        gameTimer.Stop();
                        break;
                    }
                    continue;
                }

                // drop off-screen
                if (drops[i].Rect.Y > ClientSize.Height + 50)
                {
                    drops.RemoveAt(i);
                    score += 1; // point for avoided drop
                }
            }

            // optional difficulty scaling
            if (score > 0 && score % 10 == 0)
            {
                dropSpawnInterval = Math.Max(6, 20 - score / 10);
                dropSpeedMin = Math.Min(12, 3 + score / 20);
                dropSpeedMax = Math.Min(16, 7 + score / 20);
            }

            Invalidate(); // redraw
        }

        private void Restart()
        {
            drops.Clear();
            lives = 3;
            score = 0;
            player.X = (ClientSize.Width - playerWidth) / 2;
            gameOver = false;
            dropSpawnInterval = 20;
            dropSpeedMin = 3;
            dropSpeedMax = 7;
            gameTimer.Start();
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            base.OnPaint(e);
            Graphics g = e.Graphics;

            // background
            using (SolidBrush b = new SolidBrush(Color.LightSkyBlue))
            {
                g.FillRectangle(b, ClientRectangle);
            }

            // player
            using (SolidBrush pb = new SolidBrush(Color.DarkRed))
            {
                g.FillRectangle(pb, player);
            }

            // drops
            using (SolidBrush db = new SolidBrush(Color.Blue))
            {
                foreach (var d in drops)
                {
                    g.FillEllipse(db, d.Rect);
                }
            }

            // UI: lives + score
            string ui = $"Životy: {lives}    Skóre: {score}";
            g.DrawString(ui, uiFont, Brushes.Black, new PointF(8, 8));

            // game over overlay
            if (gameOver)
            {
                string go = "GAME OVER";
                string restart = "Klikni myší nebo stiskni R pro restart";
                using (var bigFont = new Font("Consolas", 32, FontStyle.Bold))
                using (var smallFont = new Font("Consolas", 12, FontStyle.Regular))
                {
                    SizeF gosz = g.MeasureString(go, bigFont);
                    SizeF rsz = g.MeasureString(restart, smallFont);
                    var gm = new SolidBrush(Color.FromArgb(200, Color.Black));
                    g.FillRectangle(gm, new RectangleF(ClientSize.Width/2 - gosz.Width/2 - 20, ClientSize.Height/2 - gosz.Height/2 - 40, gosz.Width + 40, gosz.Height + rsz.Height + 40));
                    g.DrawString(go, bigFont, Brushes.White, new PointF(ClientSize.Width/2 - gosz.Width/2, ClientSize.Height/2 - gosz.Height/2 - 20));
                    g.DrawString(restart, smallFont, Brushes.White, new PointF(ClientSize.Width/2 - rsz.Width/2, ClientSize.Height/2 + 20));
                }
            }
        }

        protected override void OnResize(EventArgs e)
        {
            base.OnResize(e);
            // keep player at bottom on resize
            player.Y = ClientSize.Height - playerHeight - 10;
        }

        private class Drop
        {
            public Rectangle Rect;
            public int Speed;
            public Drop(Rectangle r, int s) { Rect = r; Speed = s; }
        }
    }
}
