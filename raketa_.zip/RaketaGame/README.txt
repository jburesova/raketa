RaketaGame - jednoduchá hra (Windows Forms)

Jak spustit:
1) Rozbal tento zip.
2) Otevři složku RaketaGame ve Visual Studio (s podporou .NET 6).
3) Build -> Run (F5).

Pokud používáš starší Visual Studio bez .NET 6 SDK, můžeš:
- změnit TargetFramework na net48 a upravit csproj (nebo vytvořit nový Windows Forms (.NET Framework) projekt a zkopírovat GameForm.cs a Program.cs do něj).

Ovládání:
- Levá / Pravá šipka: pohyb
- Klik myší nebo R: restart po Game Over
